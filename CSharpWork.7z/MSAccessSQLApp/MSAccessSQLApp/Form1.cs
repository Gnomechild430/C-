﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MSAccessSQLApp
{


    public partial class Form1 : Form
    {
        System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();



        public Form1()
        {
            InitializeComponent();

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.KeyCode == Keys.F5)
                MessageBox.Show("RUN SQL TEST");
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void toolStripButton2_Click(object sender, EventArgs e)
        {

          //  MessageBox.Show(conn.ConnectionString.ToString());
            if (conn.State != ConnectionState.Open)
            {

                
                    OpenFileDialog dialog = new OpenFileDialog();
                    dialog.Filter = "Access 2000-2003 (*.mdb)|*.mdb|Access 2007 (*.accdb)|*accdb";


                try
                {
                    DialogResult result = dialog.ShowDialog();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());

                }
                

               


                //if (dialog.ShowDialog() == DialogResult.OK)
                //{
                try
                {
                    string path = dialog.FileName;

                    conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;" +
                    @"Data source= " + path + "";


                    lblConnectTo.Text = path.ToString();

                    toolStripButton2.Text = "Disconnect";

                    conn.Open();
                  //  MessageBox.Show(conn.ConnectionString.ToString());
                }

                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());

                }

            }


            else
            {
                conn.Close();
                MessageBox.Show("Disconnected");
                toolStripButton2.Text = "Add Connection";

            }

            //else

            //{
            //    MessageBox.Show("No Database Selected");

            //}




        }


        //else
        //{


        //         conn.Close();
        //           lblConnectTo.Text = "Nothing";
        //            MessageBox.Show("Disconnected");
        //}


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            var sqlEntry = richTextBox1.Text;
            var elements = sqlEntry.Split(new[]  { ";" } , System.StringSplitOptions.RemoveEmptyEntries);


            foreach (string items in elements)
            {
                try
                {



                    if (conn.State == ConnectionState.Closed)
                    {
                        conn.Open();
                    }

                    OleDbCommand cmd = new OleDbCommand(items, conn);
                    int numberOfRecords = cmd.ExecuteNonQuery();
                    MessageBox.Show(items);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Updated " + numberOfRecords.ToString() + " Rows with no errors");
                    conn.Close();


                }



                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);

                }

            }
        }

          private void toolStripButton3_Click(object sender, EventArgs e)


        {
          

            string dummyFileName = "SQL.txt";

            SaveFileDialog sf = new SaveFileDialog();
         
            sf.FileName = dummyFileName;

            if (sf.ShowDialog() == DialogResult.OK)
            {
           
                string savePath = Path.GetDirectoryName(sf.FileName);
             
                TextWriter writer = new StreamWriter(@""+savePath+"/"+dummyFileName+"");
                writer.Write(richTextBox1.Text);
                   writer.Close();
                MessageBox.Show("Exported");
    

            }


        }



    }


    } 
    

