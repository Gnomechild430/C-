﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
namespace SalesMdbValidator
{
    public class RunCheck
    {
        /// <summary>
        /// Gets Data from given query and outputs to path 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="query"></param>
        /// <param name="ReaderNo"></param>
        /// <param name="outputPath"></param>
        /// <returns>
        /// Returnss Data Reader Results to txt file given as outputPath
        /// /// 
        /// </returns>
        public OleDbDataReader GetData(string connectionString, string query, int ReaderNo, string outputPath)
        {


            OleDbConnection conn = new OleDbConnection(connectionString);
            

                OleDbCommand command = new OleDbCommand(query, conn);
                int count = 0;
                try
                {
                    conn.Open();


                    DataTable dt = conn.GetSchema("Tables");

                    // Sales.mdb has 47 rows. Need to find a better way of identifying.
                    if (dt.Rows.Count != 47)
                    {
                        MessageBox.Show("Incorrect Database Input, please ensure that you select a sales.mdb");
                        return null;
                    }


                 

                    //try end 
                }


                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());

                }
                if (ReaderNo == 1)
                {
                    try
                    {

                        using (TextWriter writer = new StreamWriter(outputPath, true))
                        {


                            OleDbDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                            if (reader.HasRows)
                            {
                                writer.WriteLine("The following sales do not have matching SalesTotal and Payment");
                                writer.WriteLine("");
                                writer.WriteLine("ReceiptNumber" + "   " + "Total Required" + "          " + "Total Given");
                            }
                            while (reader.Read())
                            {


                                writer.WriteLine(reader["SaleNo"].ToString() + "       " + reader["SumKasse"].ToString() + "                  " + reader["EndTotal"].ToString());
                                count++;


                            }
                            writer.WriteLine("-----------------------------------------------------------------------------------------------------------------");
                            return reader;
                        
                        

                    }
                    }

                    catch
                    {
                        MessageBox.Show("Error with database input, please check that it is a Sales.MDB format");
                        return null;
                    }
                }



                if (ReaderNo == 2)
                {
                    try
                    {
                        using (TextWriter writer = new StreamWriter(outputPath, true))
                        {

                            OleDbDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                            if (reader.HasRows)
                            {

                                writer.WriteLine("The receipts numbers are in VerkKasse but not Zahlungen");
                                writer.WriteLine("");
                                writer.WriteLine("Zahlungen" + "        " + "VerkKasse");
                            }
                            while (reader.Read())
                            {


                                writer.WriteLine(reader["Zahlungen"].ToString() + "       " + reader["VerkKasse"].ToString());
                                count++;


                            }

                            return reader;
                        }
                    }
                    catch
                    {
                        MessageBox.Show("Error with database input, please check that it is a Sales.MDB format");
                    }

                }

                if (ReaderNo == 3)
                {

                    using (TextWriter writer = new StreamWriter(outputPath, true))
                    {

                        OleDbDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                        if (reader.HasRows)
                        {

                            writer.WriteLine("These items are in sales but not ArtikelDat");
                            writer.WriteLine("");
                            writer.WriteLine("BelegNr" + "                  " + "LiefartNr");
                        }

                        while (reader.Read())
                        {


                            writer.WriteLine(reader["BelegNr"].ToString() + "                  " + reader["LiefArtnr"].ToString());
                            count++;


                        }

                        return reader;
                    }

                }

           
                return null;



            }

        }

    
    }
    



















           





        
    

