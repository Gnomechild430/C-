﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Diagnostics;


namespace SalesMdbValidator
{
    public partial class frmMain : Form
    {

        System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();



        string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
        public List<String> chkList = new List<String>();
        public List<String> chkDesc = new List<String>();

        DataAccess da = new DataAccess();
        DBHelper dbhelp = new DBHelper();
        RunCheck check = new RunCheck();


        //Pop list with default checks

        string query1 = "SELECT VerkKasse.BelegNr AS SaleNo, Round(EndTotal) as EndTotal, Round(SumKasse,1) as SumKasse FROM" +
        "(SELECT BelegNr, SUM(Menge* SkontoVK) as SumKasse FROM VerkKasse GROUP BY BelegNr) Kasse" +
        " INNER JOIN" +
          " (SELECT Zahlungen.belegnummer, SUM(Wechselgeld) AS Change, Max(IndexNr) AS MaxIn, (Change / MaxIn) AS TotalChange, SUM(Betrag) AS TotalGiven," +
            "(TotalGiven - TotalChange) AS EndTotal From Zahlungen Group by belegnummer, Wechselgeld) Za" +
                " ON Kasse.BelegNr = za.Belegnummer" +
                    " where Kasse.SumKasse<> za.EndTotal";
        string errMsg1 = " - Do payments and item totals match up - ";


        string query2 = "SELECT Zahlungen.belegnummer as Zahlungen, VerkKasse.BelegNr" +
                        " AS VerkKasse FROM VerkKasse LEFT JOIN Zahlungen on VerkKasse.BelegNr = zahlungen.Belegnummer where Zahlungen.Belegnummer IS NULL";
        string errMsg2 = " - Receipt numbers in payments but not in sales tables - ";


        string query3 = "SELECT BelegNr,Liefartnr FROM VerkKasse WHERE NOT EXISTS (SELECT liefartnr FROM ArtikelDat WHERE ArtikelDat.Liefartnr = VerkKasse.Liefartnr)";
        string errMsg3 = " - Items in the sales tables which are not in the article data tables - ";



        public frmMain()
        {

            InitializeComponent();

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {


            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Access 2000-2003 (*.mdb)|*.mdb|Access 2007 (*.accdb)|*accdb";
            DialogResult result = dialog.ShowDialog();


            if (result == DialogResult.OK)
            {
                string path = dialog.FileName;
                try
                {
                    txtPath.Text = path.ToString();


                }
                catch (IOException) { }
            }

            else
            {
                MessageBox.Show("Invalid Format");
            }

        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            progressBar1.Value = 0;
            //1
            if (txtErrorPath.Text != "")
            {


 int barmax = chkList.Count();
                // MessageBox.Show(barmax.ToString());
                progressBar1.Maximum = (barmax + 1);

                txtLogs.AppendText("Starting Checks...... " + Environment.NewLine);
                txtLogs.AppendText(" " + Environment.NewLine);

                progressBar1.Value += 1;

                string path = txtPath.Text;

                string connectionString = dbhelp.GetConnectionString(path);

                string outputPath = txtErrorPath.Text;

                int i = 0;

                bool incorrectDBFormat = da.CheckIfSalesMDB(connectionString);

                //2
                if (incorrectDBFormat == true)
                {
                    foreach (var q in chkList)
                    {

                        var reader = da.RunErrorCheck(connectionString, q, outputPath, chkDesc[i]);



                        txtLogs.AppendText("Checking:" + "  " + chkDesc[i]);
                        txtLogs.AppendText(Environment.NewLine);
                        txtLogs.AppendText(Environment.NewLine);

                        progressBar1.Value += 1;

                        

                        i++;


                        if (reader != null)
                        {

                            txtLogs.AppendText("[Errors Found]");
                            txtLogs.AppendText(Environment.NewLine);
                            txtLogs.AppendText(Environment.NewLine);
                            lblarrow.Visible = true;
                            btnErrorLog.Visible = true;


                        }
                        else
                        {
                            
                            txtLogs.AppendText("[No Errors Found]");
                            txtLogs.AppendText(Environment.NewLine);
                            txtLogs.AppendText(Environment.NewLine);
                        }




                    }

                    txtLogs.AppendText("All Checks Complete!");




                }


                
                

                else
                {
                    txtLogs.Text = "";
                    progressBar1.Value = 0;
                    MessageBox.Show("Incorrect Databse Format Selected, ensure that you have selected a sales.mdb");
                }




                
                ////////////////////////////////////////1


            }
            else
            {
                MessageBox.Show("You must select a location to save the possible error logs");
            }
        }







        private void btnErrorLog_Click_1(object sender, EventArgs e)
        {
            string outputPath = txtErrorPath.Text;
            Process.Start(outputPath);
        }

        private void btnAddCheck_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtDesc.Text) || string.IsNullOrWhiteSpace(txtSQL.Text))
                {
                MessageBox.Show("Field(s) Missing!");
            }

            else {
                chkList.Add(txtSQL.Text);
                chkDesc.Add(txtDesc.Text);

                lstChecks.Items.Add(" - " + txtDesc.Text + " - ");


                txtSQL.Text = "";
                txtDesc.Text = "";
            }

         
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            // populate list with the default checks. These can be added to by declaring above and init below. Could improve by populating list in a different way to so you 
            // can add to default list from GUI.

            chkList.Add(query1);
            chkList.Add(query2);
            chkList.Add(query3);

            chkDesc.Add(errMsg1);
            chkDesc.Add(errMsg2);
            chkDesc.Add(errMsg3);


            lstChecks.Items.Add(chkDesc[0]);
            lstChecks.Items.Add(chkDesc[1]);
            lstChecks.Items.Add(chkDesc[2]);


    
           
            lblUser.Text = userName;


        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();

            string dummyFileName= "ErrorLog_" + System.IO.Path.GetFileNameWithoutExtension(txtPath.Text) + ".txt";
           
            sf.FileName = dummyFileName;

            

            if (sf.ShowDialog() == DialogResult.OK)
            {

                try
                {
                 //   string savePath = Path.GetDirectoryName(sf.FileName);
                  //  string location = savePath + dummyFileName;
                    txtErrorPath.Text = sf.FileName;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

     
    }
}
