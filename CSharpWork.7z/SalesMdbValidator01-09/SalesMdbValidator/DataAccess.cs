﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using Microsoft.CSharp;
using System.CodeDom.Compiler;
using System.Reflection;

namespace SalesMdbValidator

{

    public class DataAccess

    {

        public bool CheckIfSalesMDB(string connectionString)

        {
            try
            {

                OleDbConnection conn = new OleDbConnection(connectionString);
                conn.Open();
                DataTable dt = conn.GetSchema("Tables");
                // if database has 47 tables then it is sales.mdb (Need to find a better way of ID'ing this
                if (dt.Rows.Count != 47)
                {
                    conn.Close();
                    return false;


                }
                else
                {

                    conn.Close();
                    return true;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
                return false;
            }
            
        }



        public OleDbDataReader RunErrorCheck(string connectionString, string query, string outputPath, string errorMsgOutput)
        {

            CSharpCodeProvider provider = new CSharpCodeProvider();
            CompilerParameters parameters = new CompilerParameters();


            List<String> columnNames = new List<String>();
            OleDbConnection conn = new OleDbConnection(connectionString);
            OleDbCommand command = new OleDbCommand(query, conn);
            conn.Open();
           


       

 
                using (TextWriter writer = new StreamWriter(outputPath, true))
                {

                //conn.Open();


                try
                {
                    OleDbDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection);




                    object[] meta = new object[10];
                    bool read;
                    if (reader.HasRows)
                    {

                        writer.WriteLine(errorMsgOutput);
                        writer.WriteLine("");




                        for (int col = 0; col < reader.FieldCount; col++)
                        {

                            writer.Write(reader.GetName(col).ToString() + "                          ");
                        }


                        writer.WriteLine("");




                        while (reader.Read())
                        {

                            do
                            {

                                int NumberOfColums = reader.GetValues(meta);

                                for (int i = 0; i < NumberOfColums; i++)
                                    writer.Write("{0}", meta[i].ToString() + "                          ");

                                read = reader.Read();
                                writer.WriteLine("", Environment.NewLine);
                            } while (read == true);
                        }
                        reader.Close();
                        return reader;
                    }
                    else
                    {
                        return null;
                    }
                   
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString() + "  ----->  " + query);
                    return null;
                }
            }

            }

        }
    }
 
