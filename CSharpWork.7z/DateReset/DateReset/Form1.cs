﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DateReset
{
    public partial class Form1 : Form
    {


        string date = "";
        public Form1()
        {
            InitializeComponent();
        }


        OS os = new OS();
      

        private void button1_Click(object sender, EventArgs e)
        {
            
                System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();

                String OS = os.GetOsInfo();

                String Arb = "";


                if (OS == "XP")


                {
                    Arb = @"C:\Documents and Settings\All Users\CSAP\Arbeitsplatz.mdb";
                    MessageBox.Show("XP");
                }

                else

                {

                    Arb = @"C:\ProgramData\CSAP\Arbeitsplatz.mdb";
                    MessageBox.Show("7+");
                }


                MessageBox.Show(Arb);


                if (File.Exists(Arb))
                {

                    String JTLocation = os.GetJTLocation(Arb);

                    if (JTLocation != "JT Location Not Found")
                    {

                        conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;" +
                         @"Data source= " + JTLocation + "";
                    }
                    else
                    {
                        MessageBox.Show(Arb);
                    }
                }


                try
                {
                    if (File.Exists(Arb))
                    {

                        conn.Open();


                        if (string.IsNullOrWhiteSpace(txtDate.Text))
                        {

                            MessageBox.Show("Daten Empty!");

                        }


                        else
                        {

                        date = txtDate.Text.ToString();
                            string strSQL = "UPDATE Stammdaten SET Daten1 = #"+ date +"# WHERE Bezeichnung = 'CS_Last_Archiv_Date' OR Bezeichnung = 'StartArtikelBerechnungen'" +
                             "OR Bezeichnung = 'StartKundenBerechnungen' OR Bezeichnung = 'StartLagerCopy' OR Bezeichnung = 'StartLieferantBerechnungen' OR " +
                            "Bezeichnung = 'DFUePersonenEinlesen' OR Bezeichnung = 'StartArtMaterialTagen' OR Bezeichnung = 'StammdatenVonZentraleEinlesen'";

                            MessageBox.Show(strSQL);


                            OleDbCommand cmd = new OleDbCommand(strSQL, conn);

                            cmd.ExecuteNonQuery();

                            MessageBox.Show("Updated");


                        }
                    }


                    else

                {
                        MessageBox.Show("ArbNotFound");

                    }
                }

                catch (Exception ex)

                {

                    MessageBox.Show("Failed due to" + ex.Message);

                }
        }

        

        //private void btnBrowse_Click(object sender, EventArgs e)
        //{
        //    OpenFileDialog dialog = new OpenFileDialog();
        //    DialogResult result = dialog.ShowDialog();


        //    if (result == DialogResult.OK) 
        //    {
        //        string path = dialog.FileName;
        //        try
        //        {
        //            txtPath.Text = path.ToString();
        //        }
        //        catch (IOException) { }
        //        }
        //    }






    }
    }

