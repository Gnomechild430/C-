﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace DateReset
{
    public class OS
    {
        public string GetOsInfo()
        {

            OperatingSystem os = Environment.OSVersion;

            Version vs = os.Version;

            string operatingSystem = "";

            switch (vs.Major)
            {
                case 3:
                    operatingSystem = "NT 3.51";
                    break;
                case 4:
                    operatingSystem = "NT 4.0";
                    break;
                case 5:
                    if (vs.Minor == 0)
                        operatingSystem = "2000";
                    else
                        operatingSystem = "XP";
                    break;
                case 6:
                    if (vs.Minor == 0)
                        operatingSystem = "Vista";
                    else
                        operatingSystem = "7";
                    break;
                default:
                    break;



            }


            return operatingSystem;

        }





        public String GetJTLocation(string arb)
        {

            try
            {

                Object returnvalue;

                MessageBox.Show(arb + "TestInClass");
                System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();



                conn.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;" +
                 @"Data source= " + arb + "";


                OleDbCommand cmd = new OleDbCommand();



                cmd.CommandText = "SELECT DatenPfad FROM ArbeitsPlatz";
                cmd.Connection = conn;


                conn.Open();

                returnvalue = cmd.ExecuteScalar();

                conn.Close();

                return returnvalue.ToString();

            }

            catch(Exception ex)
            {

                MessageBox.Show(ex.Message);
                return "JT Location Not Found";

            }

        }


    }
}

