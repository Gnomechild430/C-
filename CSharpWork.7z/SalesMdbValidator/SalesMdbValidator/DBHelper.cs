﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace SalesMdbValidator
{
    public class DBHelper
    {

        public string GetConnectionString(string path)
        {
            string ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data source=" + path + " ";

            return ConnectionString;

            

        }


        public void OpenFile(string FilePath)
        {

            Process.Start(FilePath);
        }

    }
}
