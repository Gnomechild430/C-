﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
namespace SalesMdbValidator


{

    public class DataAccess
    {


        public OleDbDataReader RunErrorCheck(string connectionString, string query, int ReaderNo, string outputPath, string errorMsgOutput)
        {


            List<String> columnNames = new List<String>();
            OleDbConnection conn = new OleDbConnection(connectionString);
            OleDbCommand command = new OleDbCommand(query, conn);

            using (TextWriter writer = new StreamWriter(outputPath, true))
            {
                OleDbDataReader reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                if (reader.HasRows)
                {

                    writer.WriteLine(errorMsgOutput);
                    writer.WriteLine("");


                    for (int col = 0; col < reader.FieldCount; col++)
                    {
                        columnNames.Add(reader.GetName(col).ToString());
                        writer.Write(reader.GetName(col).ToString());
                    }

                    while (reader.Read())
                    {
                        // Need some code that checks how many columns there are, without doing If reader.fieldcount = 2 then output [0] , [1] etc.. 
                        writer.WriteLine((reader[0]) + "       " + reader[1].ToString() + "           " + reader[2].ToString());

                    }
                    return reader;

                }

                return null;
 }

        }
 }
} 
