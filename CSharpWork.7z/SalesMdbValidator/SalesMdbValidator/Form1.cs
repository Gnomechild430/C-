﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;
using System.Diagnostics;


namespace SalesMdbValidator
{
    public partial class Form1 : Form
    {

        System.Data.OleDb.OleDbConnection conn = new System.Data.OleDb.OleDbConnection();

          
        
                    

    DBHelper dbhelp = new DBHelper();
        RunCheck check = new RunCheck();




        public Form1()
        {

            InitializeComponent();

        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {


            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "Access 2000-2003 (*.mdb)|*.mdb|Access 2007 (*.accdb)|*accdb";
            DialogResult result = dialog.ShowDialog();


            if (result == DialogResult.OK)
            {
                string path = dialog.FileName;
                try
                {
                    txtPath.Text = path.ToString();


                }
                catch (IOException) { }
            }

        }

        private void btnCheck_Click(object sender, EventArgs e)
        {



            textBox1.AppendText("Starting Checks...... " + Environment.NewLine);
            textBox1.AppendText(" " + Environment.NewLine);

            progressBar1.Value += 1;

            string path = txtPath.Text;

            string connectionString = dbhelp.GetConnectionString(path);

            string outputPath = @"E:/ErrorLog_" + System.IO.Path.GetFileNameWithoutExtension(path) + ".txt";



            string query1 = "SELECT VerkKasse.BelegNr AS SaleNo, EndTotal, SumKasse FROM" +
            "(SELECT BelegNr, SUM(Menge* SkontoVK) as SumKasse FROM VerkKasse GROUP BY BelegNr) Kasse" +
            " INNER JOIN" +
            " (SELECT Zahlungen.belegnummer, SUM(Wechselgeld) AS Change, Max(IndexNr) AS MaxIn, (Change / MaxIn) AS TotalChange, SUM(Betrag) AS TotalGiven," +
            "(TotalGiven - TotalChange) AS EndTotal From Zahlungen Group by belegnummer, Wechselgeld) Za" +
            " ON Kasse.BelegNr = za.Belegnummer" +
            " where Kasse.SumKasse<> za.EndTotal";


            string query2 = "SELECT Zahlungen.belegnummer as Zahlungen, VerkKasse.BelegNr" +
            " AS VerkKasse FROM VerkKasse LEFT JOIN Zahlungen on VerkKasse.BelegNr = zahlungen.Belegnummer where Zahlungen.Belegnummer IS NULL";


            string query3 = "SELECT BelegNr,Liefartnr FROM VerkKasse WHERE NOT EXISTS (SELECT liefartnr FROM ArtikelDat WHERE ArtikelDat.Liefartnr = VerkKasse.Liefartnr)";



            var reader1 = check.GetData(connectionString, query1, 1, outputPath);


            progressBar1.Value += 1;


            if (reader1 != null)
            {
                
                if (reader1.HasRows)
                {

                    btnErrorLog.Enabled = true;

                    textBox1.AppendText("[ERROR: Payments and Sale Total not equal]" + Environment.NewLine);


                    textBox1.AppendText(" ");
                    textBox1.AppendText(Environment.NewLine);
                    conn.Dispose();
                //    MessageBox.Show(conn.State.ToString());

                }






                var reader2 = check.GetData(connectionString, query2, 2, outputPath);


                progressBar1.Value += 1;
                if (reader2 != null)
                {
                   

                    if (reader2.HasRows)
                    {

                        btnErrorLog.Enabled = true;
                        textBox1.AppendText("[ERROR:Receipt numbers missing from either Zahlungen that are in VerkKasse]" + Environment.NewLine);
                        textBox1.AppendText(" ");
                        textBox1.AppendText(Environment.NewLine);
                        conn.Dispose();
                      //  MessageBox.Show(conn.State.ToString());


                    }


                    


                }


               


                var reader3 = check.GetData(connectionString, query3, 3, outputPath);

                progressBar1.Value += 1;

                if (reader3 != null)
                {
                    


                    if (reader3.HasRows)
                    {

                        btnErrorLog.Enabled = true;
                        textBox1.AppendText("[ERROR:Items found in Sales data not in ArtikelDat]" + Environment.NewLine);
                        textBox1.AppendText(" ");
                        textBox1.AppendText(Environment.NewLine);
                         conn.Dispose();
           


                    }



                    progressBar1.Value += 1;
                    textBox1.AppendText("-- Checks Complete --" + Environment.NewLine);
                    textBox1.AppendText(" " + Environment.NewLine);
                    textBox1.AppendText(" -- Click View Error Log to view errors -- ");
                    btnCheck.Enabled = false;
                }

                if (textBox1.Text == "")
                {
                    progressBar1.Value = 5;
                    textBox1.Text = "No Errors Found";
                }



            }



            else
            {   
                textBox1.Text = "";
                progressBar1.Value = 0;
                
            }
        }


    private void btnErrorLog_Click_1(object sender, EventArgs e)
        {
            string outputPath = "E:/ErrorLog_" + System.IO.Path.GetFileNameWithoutExtension(txtPath.Text) + ".txt";
            Process.Start(outputPath);
        }

    }
}

