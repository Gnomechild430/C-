﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEControlsBI
{
    public class Mapping
    {



        
        //public static List<string> Customers = new List<String>();
        //public static List<int> Target = new List<int>();
        //public static List<int> salesValue = new List<int>();
        //public static List<int> variance = new List<int>();
        
    }
 
}
