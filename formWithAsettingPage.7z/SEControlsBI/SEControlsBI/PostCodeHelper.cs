﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.IO;
using System.Data;


namespace SEControlsBI
{
    public class PostCodeHelper
    {

        static DataTable postCodeTable = new DataTable();
        
        

/// <summary>
/// Gets the area of the given postcode, enabling it to be mapped.
/// </summary>
/// <param name="PostCode"></param>
/// <returns></returns>
        public string GetSector(string PostCode)
        {
            string result = "";
            try
            {

                string postcode = PostCode;
                string[] pcsplit = postcode.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                string area;
                int areaLen = 0;
                Char[] asChars = pcsplit[0].ToCharArray();
                if (Char.IsDigit(asChars[1]))
                {
                    areaLen = 1;
                }
                else
                {
                    areaLen = 2;
                }
                area = pcsplit[0].Substring(0, areaLen);
                string district = pcsplit[0].Substring(areaLen); ;
                string sector = pcsplit[1].Substring(0, 1);
                string unit = pcsplit[1].Substring(1);
                result = area.ToString();
                
            }
            catch (Exception)
            {

            }

            finally
            {
               
            }

            return result;
        }

        public DataTable GetPostCodesFromCSV()
        {
            postCodeTable.Columns.Add("Col1", typeof(String));
            postCodeTable.Columns.Add("Col2", typeof(String));
           

            using (var reader = new StreamReader("PostcodeMappingRegions2.csv"))
            {

                List<string> listA = new List<string>();
                List<string> listB = new List<string>();


                while (!reader.EndOfStream)
                {
                    DataRow row = postCodeTable.NewRow();
                    var line = reader.ReadLine();
                    var values = line.Split(',');
                    
                    row[0] = values[0].ToString();
                    row[1] = values[1].ToString();

                    postCodeTable.Rows.Add(row);
                }

                return postCodeTable;

            }


        }




    }
}
