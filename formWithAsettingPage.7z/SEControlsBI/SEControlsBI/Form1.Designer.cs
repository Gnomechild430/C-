﻿namespace SEControlsBI
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        /// 
        public void DrawGrid(int rowCount)
        {
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(22, 104);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowTemplate.Height = rowCount;
            this.dataGridView1.Size = new System.Drawing.Size(519, 344);
            this.dataGridView1.TabIndex = 4;
        }

     
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendEmailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblEmailLoad = new System.Windows.Forms.Label();
            this.txtSearch = new System.Windows.Forms.TextBox();
            this.lblSearch = new System.Windows.Forms.Label();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(552, 24);
            this.menuStrip1.TabIndex = 3;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem,
            this.sendEmailToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // sendEmailToolStripMenuItem
            // 
            this.sendEmailToolStripMenuItem.Name = "sendEmailToolStripMenuItem";
            this.sendEmailToolStripMenuItem.Size = new System.Drawing.Size(132, 22);
            this.sendEmailToolStripMenuItem.Text = "Send Email";
            this.sendEmailToolStripMenuItem.Click += new System.EventHandler(this.sendEmailToolStripMenuItem_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Location = new System.Drawing.Point(21, 67);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(10, 11);
            this.dataGridView1.TabIndex = 12;
            this.dataGridView1.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(345, 27);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 21);
            this.button3.TabIndex = 5;
            this.button3.Text = "Run";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Customer Order Analysis "});
            this.comboBox1.Location = new System.Drawing.Point(161, 27);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(165, 21);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.TextChanged += new System.EventHandler(this.comboBox1_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(136, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Query to run (All customers)";
            // 
            // lblEmailLoad
            // 
            this.lblEmailLoad.AutoSize = true;
            this.lblEmailLoad.Location = new System.Drawing.Point(817, 329);
            this.lblEmailLoad.Name = "lblEmailLoad";
            this.lblEmailLoad.Size = new System.Drawing.Size(0, 13);
            this.lblEmailLoad.TabIndex = 9;
            this.lblEmailLoad.Visible = false;
            // 
            // txtSearch
            // 
            this.txtSearch.AutoCompleteCustomSource.AddRange(new string[] {
            "W M Brown",
            "BILCO UK",
            "Nationwide Specialist Projects (NSP) Ltd",
            "FOSTERS WINDOW CONTROLS LTD",
            "Air Design Systems Ltd",
            "ADEXSI UK",
            "SHEVTECH LTD",
            "Midland Signal Limited",
            "JCR SECURITY LTD",
            "ALUMINIUM DOOR SUPPLIES",
            "SILVER GROUP",
            "LTL Systems",
            "WM BROWN & CO (MAINTENANCE) LTD",
            "FIRE TEC GOLD LTD",
            "SHEV Services",
            "FIRE BRIGHT SOLUTIONS LTD",
            "LORNE STEWART PLC",
            "Profire Engineering Ltd",
            "McMULLEN FACADES LTD",
            "ALUMET SYSTEMS (UK) LTD",
            "DUDLEY\'S  ALUMIMNIUM",
            "ROOFGLAZE LIMITED",
            "GLAZING VISION LTD",
            "Atech UK",
            "XTRALITE (ROOFLIGHTS) LTD",
            "ESB SERVICES LTD",
            "Duplus Ltd",
            "WALSIN  LTD",
            "D.I.S ELECTRICAL CONTRACTORS LTD",
            "JPJ INSTALLATIONS LTD",
            "COMPLETE FIRE SOLUTIONS LTD",
            "SWEGON AIR MANAGEMENT LIMITED",
            "ACCOUNTING SERVICE CENTRE G4S",
            "COLT INTERNATIONAL LTD",
            "AOV UK Ltd",
            "AB Glass (Door and Windows) Ltd",
            "Total Glass",
            "GORDON ELECTRICAL SERVICES LTD",
            "Lareine Engineering Ltd",
            "COLT INTERNATIONAL LIMITED",
            "MB Glass Supplies Ltd",
            "ASTROFADE",
            "G.S. STOTHERS",
            "Tradecraft",
            "QUEST SOLUTIONS UK LTD",
            "Fortem Energy Services Ltd",
            "FOX ALUMINIUM SYSTEMS LTD",
            "BRAKEL AIRVENT LTD",
            "Newbury Commercial Glazing Ltd",
            "Cannon Glass and Glazing Ltd",
            "Cambs Glass",
            "BRETT MARTIN DAYLIGHT SYSTEMS LTD",
            "MWE LTD",
            "EXA ALUMINIO SA -",
            "AIRE-VALLEY ARCHITECTURAL ALUMINIUM LTD",
            "APIC UK",
            "SEH Commercial Ltd",
            "ROBERTSON CONSTRUCTION CENTRAL LTD",
            "BONNELLS ELECTRICAL CONTRACTORS LTD",
            "KINGFISHER WINDOWS",
            "VITRAL A/S",
            "INTERSERVE FS (UK) LTD",
            "CBA Trade GmbH",
            "SMOKE & ENVIRONMENTAL CONTROLS AFRICA",
            "NORTH CHESHIRE HOLDINGS LTD",
            "TENON FM LTD",
            "MURUS FACADES LTD",
            "RYNESS ELECTRICAL LTD",
            "SOLAR VISION LIMITED",
            "QUALITY GLASS (STOKE-ON-TRENT) LTD",
            "AUTOMATED SYSTEMS MAINTENANCE",
            "SCS AFTERCARE",
            "F.A.Firman (Glass Projects) Ltd",
            "INASUS UK",
            "Colden Nottingham Ltd",
            "LEICESTER UNIVERSITY",
            "N",
            "FIRE AND SECURITY CONSULTANCY LTD",
            "PARK ARCHITECTURAL LTD",
            "FIRE SYSTEMS LTD",
            "W.A.S.P. LTD",
            "SES (ENGINEERING) SERVICES LTD",
            "WALT\'S INSPECTION SERVICE LLC",
            "ENTERPRISE SECURITY DISTRIBUTION (NORFOLK) LTD",
            "ELITE ALUMINIUM SYSTEMS LTD",
            "PRIMA SYSTEMS LTD",
            "RGE SERVICES",
            "Vision AGI Limited",
            "McKENZIE-MARTIN LTD",
            "VITRAL UK LTD",
            "University of Derby",
            "AMTHAL FIRE & SECURITY LTD",
            "SD FERAL CO S.R.L.",
            "LM INSTALLATIONS LTD",
            "Euro Games Technology Multiplayer Solutions  Ltd",
            "EAST YORKSHIRE GLAZING",
            "ACUMEN TECHNICAL LTD",
            "NATURALIGHT SYSTEMS LTD",
            "SSE ENTERPRISE",
            "Ambient Environmental Solutions Ltd",
            "METNOR CONSTRUCTION LTD",
            "ALUMINIUM SASHES",
            "APPELLO",
            "GLASSOLUTIONS INSTALLATION",
            "S Van de Gevel T/A BlueSquared",
            "BILCO (US)",
            "C.E.F GROUP OFFICE  (LONDON NORTH WEST)",
            "FIRE SAFETY SERVICES",
            "Walker Miller & Co Ltd",
            "McArthur Agriculture",
            "STS LIMITED",
            "Breathing Buildings Ltd",
            "CLOSE CIRCUIT SECURITY SERVICES",
            "Tomlinson-Longstaff Ltd",
            "Propak Architectural Glazing Ltd",
            "DRAYTON WINDOWS LTD",
            "Sheffield City Council",
            "V-TECH SOLUTIONS UK LTD",
            "DH Electrical Services",
            "SMOKE TECH LTD",
            "COMMERCIAL SYSTEMS INTERNATIONAL",
            "Churches Fire Security Ltd",
            "K.G.SMOKE DISPERSAL",
            "SKANSKA RASHLEIGH WEATHERFOIL LTD",
            "BAYDALE CONTROL SYSTEMS",
            "SPEC-AL FACADES LTD",
            "CEF Group Office (Hinckley)",
            "Sheridan M&E Ltd",
            "T Clarke Leeds Ltd",
            "The Parkside Group Limited",
            "WITT & SON UK LTD",
            "REXEL UK - AP DEPARTMENT (M3)",
            "CROP SYSTEMS LTD",
            "TIME ELECTRICAL WHOLESALE LTD",
            "Life Safety Systems Ltd",
            "Rooflight Architectural Ltd",
            "PYROTEC FIRE DETECTION",
            "Firefly Security (UK) Ltd",
            "Alphatrack Systems Ltd",
            "MAXLIGHT",
            "HES FIRE PROTECTION LTD",
            "SIMPSON YORK",
            "Stig Wahlström Oy",
            "Alpha Structures",
            "L2i Architectural Aluminium Ltd",
            "UBS Group",
            "Nationwide Electrical Installations Ltd",
            "FES FM LTD",
            "MELLOR TOPS MAINTENANCE",
            "MICHAEL J LONSDALE LTD",
            "The New School",
            "KM SERVICES",
            "IQ Fire Solutions Ltd",
            "CANTIFIX LTD",
            "NATURAL DAYLIGHT SOLUTIONS LTD",
            "Syntec Projects Ltd",
            "SCCI ALPHATRACK LTD",
            "Polar NE Limited",
            "ADCO Glazing Ltd",
            "ACCESS DOORS LTD",
            "EDSB Fire & Security",
            "MC CONTROLS PANELS LTD",
            "ADVANCED ELECTRICAL CONTROLS",
            "PETER MOORE",
            "JET COX LTD",
            "J G COMMUNICATIONS 1066 LTD",
            "VJ Technology",
            "JEFF WAY ELECTRICAL SERVICES LTD",
            "SOUTH EAST FIRE & SECURITY",
            "Camel Glass",
            "OPENVIEW SECURITY SOLUTIONS LTD",
            "Raven Electrical Services",
            "AYLESFORD ELECTRICAL CONTRACTORS",
            "PLUMB CENTRE NEATH",
            "HOWARTH HOMES",
            "ODC Door & Glass Systems Ltd",
            "WHITESALES LLP t/as WHITESALES",
            "PSB",
            "FIRE EQUIPMENT SERVICES LIMITED",
            "S GERAGHTY ELECTRICAL SERVICES",
            "ELECTRIC SKYLIGHT COMPANY",
            "FACILITIES MANAGEMENT SERVICES UK LTD",
            "MEDLOCK ELECTRICAL DISTRIBUTORS",
            "Genuine Interiors Ltd",
            "NATRALIGHT LIMITED",
            "EQUIPOL, S.A. DE C.V.",
            "Acorn Fire & Security LTD",
            "FOLIO UK LIMITED",
            "MALTHOUSE SECURITY LTD",
            "JC MAINTENANCE SERVICES LTD",
            "MAC ALARMS LTD",
            "DYER ENVIRONMENTAL CONTROLS LTD",
            "FUSED TECHNOLOGY SOLUTIONS",
            "Martec Engineering Ltd",
            "Sherwood Fire",
            "FIRECREST SERVICES LTD",
            "BELL LANCASTER LTD T/A AMM FIRE SAFETY",
            "Mercuri (Architectural Sales) Ltd",
            "FIRE-POINT-UK LTD",
            "APROPOS CONSERVATORIES LIMITED",
            "BUILD & MAINTAIN LTD",
            "Edmundson Electrical Ltd",
            "BBC FIRE PROTECTION",
            "LODDON DOOR SERVICES LTD",
            "LH EVANS",
            "UNIVERSITY OF SHEFFIELD",
            "BAUMAC ENGINEERING LTD",
            "LONSDALE METAL CO LTD",
            "A.B. KEY LLP",
            "HUMMERSKNOTT ACADEMY TRUST",
            "EQUIPTEST LTD",
            "SKANSKA RASHLEIGH WEATHERFOIL LTD",
            "EVANDER GLAZING & LOCKS LTD",
            "Onyx Facilities Services",
            "AIR COOL ENGINEERING SERVICE AND MAINTENANCE LTD",
            "Shane Juggins",
            "FIRE FACILITIES MANAGEMENT LTD",
            "DERRY LIMITED",
            "INTERSERVE FM LTD",
            "Airtech Optimise Ltd",
            "CRITTALL WINDOWS",
            "ASVS LTD",
            "ROOF VENT UK LIMITED",
            "FIRETECNICS SYSTEMS LTD",
            "Loxford School Trust",
            "G.K.R Services Ltd",
            "BLABY ELECTRICAL LTD",
            "PILKINGTON TECHNOLOGY MANAGEMENT LTD",
            "FTS FIRE & SECURITY LTD",
            "CLEVELAND METAL WINDOW SERVICE",
            "CANNON ELECTRICAL CONTRACTORS",
            "NORTH MIDLAND CONSTRUCTION PLC",
            "Breakwells Glass",
            "Cambridge Electrical Wholesale Ltd",
            "THE BURSARY",
            "DAVENHEATH LTD",
            "Travis Perkins/Keyline",
            "Blou Construction",
            "Tencer Ltd",
            "VGI Security",
            "CELSIUS DESIGN LTD",
            "TNE Electrical",
            "GLASSHUS ARCHITECTURAL ALUMINIUM",
            "ALLIED PROTECTION LTD",
            "Fixatex Ltd",
            "A1 Tools & Fixings Ltd",
            "G S Electrical Services",
            "GRADWOOD LIMITED",
            "CBRE MANAGED SERVICES LTD",
            "Sparks Electrical Installations Limited",
            "HAZLEMERE WINDOW CO LTD",
            "INDEPENDENT SECURITY SUPPLIES LTD",
            "ALI SYSTEMS LTD",
            "Medlock Electrical Distributors",
            "Callfire Systems Ltd",
            "Wolseley  UK  Ltd",
            "FK CONSTRUCTION LIMITED",
            "NYKE ENERGY SERVICES LTD",
            "Edmundson Electrical",
            "Alltype Fire & Facilities Ltd",
            "MJ FIRE SAFETY LTD",
            "Alufix UK Ltd",
            "CAPITOL ENGINEERING SERVICES LTD",
            "BORRAS CONSTRUCTION LTD",
            "Alco Glass Systems Ltd",
            "City Axis Limited",
            "DEPARTMENT OF INFRASTRUCTURE",
            "Kiasu Group",
            "UK GLASS LTD",
            "Paul Evans Architectural",
            "CAMBRIDGE MAINTENANCE SERVICE LTD",
            "PURE ALARMS",
            "R & M Door Engineering Ltd",
            "Interserve Estates",
            "C&T ELECTRICAL CONTRACTORS LTD",
            "RYDON MAINTENANCE LIMITED",
            "Unite Integrated Solutions Plc",
            "Ayton & McKeown",
            "Phoenix ME Limited",
            "WESTERN AUTOMATION",
            "HOXON",
            "Simon Dean Electrical Ltd",
            "CRS Communications Limited",
            "WESTERN AUTOMATION ETS",
            "\"\tB&F - Edmundson\"",
            "Prism Architectural Ltd",
            "D S R MECHANICAL SERVICES LTD",
            "ADVANCED FIRE & SECURITY SERVICES LTD",
            "NATIONWIDE FIRE & SECURITY (UK) LTD",
            "MILLWOOD SERVICING LTD",
            "Rafport",
            "Great Torrington Bluecoat C of E Primary School",
            "MALT HOUSE SECURITY",
            "Metali Window Service Ltd",
            "Ridgeway Glazing Ltd",
            "DB AUDIO & ELECTRONIC SERVICES LTD",
            "LEDSITE",
            "ADT FIRE AND SECURITY PLC",
            "INTERSERVE ENGINEERING SERVICES LTD",
            "QUANTUM GROUP SERVICES LTD",
            "Bracknell Forest Homes Limited",
            "Edmundson Electrical Ltd",
            "S & S QUALITY BUILDING CONTRACTORS LIMITED",
            "EXCEL 200 WINDOWS LTD",
            "The Electrical Network Ltd",
            "HERIOT-WATT UNIVERSITY",
            "I D SYSTEMS",
            "VolkerFitzpatrick",
            "William Hale Fire & Security",
            "CREST GLAZING LTD",
            "NTP-HOISTAID LIMITED",
            "Focus Building",
            "EFT SYSTEMS LTD",
            "Sunfish Services Limited",
            "Mr & Mrs Stuart Harrison",
            "THOMASONS ELECTRICAL SERVICES",
            "PROLEC ELECTRICAL (NW) LTD",
            "Quebec Quay (Liverpool) Management Limited",
            "VACS (SW) LTD",
            "London School of Economics",
            "THOMAS DOOR AND WINDOW CONTROLS",
            "Britannia Fire & Security Ltd",
            "T&P FIRE LTD",
            "MR ANDY CROOK",
            "KONNECT SCOTLAND",
            "Switch Electrical Wholesale Limited",
            "Adams Construction and Consultancy",
            "Homecare Windows",
            "IN HOUSE CONSTRUCTION",
            "NEWCASTLE CITY COUNCIL",
            "C&M FIRE ALARMS LTD",
            "Woodhouse Environmental Services Ltd",
            "DS Electrical",
            "SPECTRUM ELECTRICAL & MECHANICAL ENGINEERS LTD",
            "CITY ELECTRICAL FACTORS (EDINBURGH SOUTH)",
            "EDMUNDSON ELECTRICAL LTD",
            "CITY ELECTRICAL FACTORS",
            "Templegate Electrical Supplies",
            "Katana Residential Ltd",
            "McINTYRE ELECTRICAL LTD",
            "WAVELEY FIRE & SECURITY LTD",
            "ABCA SYSTEMS LTD",
            "ALUCRAFT SYSTEMS LTD",
            "S. LAMYMAN & SON LTD",
            "QUANDEK LTD",
            "SKYVENT SYSTEMS T/AS CONSERVATORY FITTINGS",
            "CITY ELECTRICAL FACTORS",
            "Hentland Group",
            "NEW CONCEPT BEYOND CATERING EQUIP LTD",
            "T G S Property Maintenance",
            "Woodfield Windows and Conservatories Ltd",
            "P D BRADY LTD",
            "Pro-Alarm Service & Installations Ltd",
            "TRAVIS PERKINS BIRKENHEAD",
            "Aurora Electronics Limited",
            "TOMTECH (UK) Ltd",
            "Digi Group",
            "ENGLISH ARCHITECTURAL GLAZING",
            "PROTEC FIRE DETECTION PLC",
            "Foris Solutions Limited",
            "Harbord Electrical Ltd",
            "LAKEVIEW PROPERTY MAINTENANCE",
            "Bridge Fire and Security Ltd",
            "North London Fire & Security Systems Ltd",
            "FORESHAW BUILDING SERVICES LTD",
            "KASA-TEC",
            "KARMA Electrical & Fire Systems Ltd",
            "Fire Alarm Installations (UK) Ltd",
            "FIREMAIN UK LTD",
            "EDMUNDSON ELECTRICAL LTD",
            "J B MAINTENANCE",
            "EURO ELECTRICAL CONTRACTORS LTD",
            "NEWEY & EYRE  (REXEL UK LTD)",
            "Paul Clarkson Electrical",
            "WF SENATE",
            "DR MICHAEL GILES",
            "3D ALUMINIUM PLAS",
            "JDL Electrical Contractors Ltd",
            "Mr Mick Railes",
            "Surrey Fire & Safety Ltd",
            "FIRE TECH SERVICES",
            "ATEC Electrical Contractors London LTD",
            "ASTRASEAL",
            "SPIE UK",
            "EDMUNDSON ELECTRICAL LTD",
            "HAYVERN ELECTRICAL LTD",
            "T Loughman & Co Ltd",
            "FIREMASTER ALARMS LIMITED",
            "PDB CONTROLS LTD",
            "Roger Wise",
            "PRESTIGE PROTEC SYSTEMS LTD",
            "PACIFIC SECURITY SYSTEMS",
            "SMAIL AND RICHARDS",
            "GCG Electrical Wholesalers",
            "OAKTREE ELECTRICAL LTD",
            "\"Calibre Building Services Ltd",
            "\"",
            "First City Fire & Security",
            "ELITE FIRE PROTECTION LTD",
            "KILPATRICK BLANE",
            "A&A ELECTRICAL DISTRIBUTORS LTD",
            "Student Accommodation Nottingham Ltd",
            "Certus Security",
            "WINTERS ELECTRICAL SERVICES LTD",
            "Amalgamated Ltd",
            "Beara Properties Ltd",
            "C J Electrical",
            "CEATON SECURITY SERVICES LTD",
            "FIRST CITY FIRE & SECURITY",
            "Fire Compliance Services",
            "HURLEY ELECTRICAL",
            "INTELLIGENT SECURITY & FIRE",
            "Integrated Protection Maintenance Limited",
            "LEADER SYSTEMS LLP",
            "NG ELECTRIC",
            "RESCOM LTD",
            "TECHNIFIRE SOLUTIONS LIMITED",
            "TUNSTALL HEALTHCARE UK LTD",
            "JAGAJENDI LLP",
            "CORMETON ELECTRONICS LIMITED",
            "Fidelity Integrated Systems Limited",
            "SURE SAFE FIRE SYSTEMS LTD",
            "SUE WEBSTER",
            "EDMUNDSON ELECTRICAL LTD",
            "C&D Electrical Contractors Limited",
            "PORSCHE CENTRE LEICESTER",
            "London Security Automation Limited",
            "CUSTOM ADVANCED SYSTEMS LTD",
            "FIRE RISK PREVENTION AGENCY LTD",
            "R Company 2 Limited",
            "MEDLOCK ELECTRICAL DISTRIBUTORS",
            "LJB Electrical Services Ltd",
            "ASRA HOUSING GROUP",
            "I-MAC FIRE & SECURITY LTD",
            "One Direct Maintenance Ltd",
            "PEL SERVICES LTD",
            "LIMEBRIGHT LTD",
            "R & M Clarkson Ltd",
            "Priority Fire & Electrical Ltd",
            "CEAS KENT LTD",
            "1ST ACE SECURITY GROUP",
            "TOTAL INTEGRATED SOLUTIONS LIMITED",
            "Merlin Point (Beechfield Estate)",
            "Electrical Smart Solutions Ltd",
            "AAES Electrical Services LTD",
            "DCA Security Systems Ltd",
            "ProActive Fire Solutions Ltd",
            "Remus Management Limited",
            "JAY SPARKS ELECTRICAL",
            "KCR Build",
            "EDMUNDSON ELECTRICAL LTD",
            "TOBBELL ELECTRICAL",
            "AT & T (GB LTD)",
            "NORMAN COOK",
            "SAFEVENT SYSTEMS GROUP",
            "AG Fire Solutions Ltd",
            "NC ELECTRICAL",
            "Bridge Fire & Security Ltd",
            "Proactive Block Management LtdLTD",
            "H & E Engineers (Oxford) Ltd",
            "NIRVANA MAINTENANCE LTD",
            "Zone Developments Leicester Limited",
            "GROUND LEVEL SERVICES LTD",
            "Specialist Building Contractors",
            "SATELLITE STEVE DIGITAL LTD",
            "Zensor Security",
            "Oakray Limited",
            "CENTRAL ELECTRICAL & LIGHTING LTD",
            "Esther Shanson",
            "HAUS BLOCK MANAGEMENT",
            "LAMPS & TUBES ILLUMINATIONS LTD",
            "MUMFORD & WOOD LTD",
            "MERVIN CAMPBELL",
            "GDC Security",
            "Feltham Construction",
            "PYROTEC SERVICES LIMITED",
            "GRAFTON MERCHANTING GB LTD",
            "LINDRICK CONSTRUCTION SERVICES LTD",
            "TVF UK PLC",
            "SFS Fire Engineering Ltd",
            "ALLROUND ELECTRICAL SERVICES LTD",
            "Steve Charles Electrical Ltd",
            "LEWIS BUILDERS"});
            this.txtSearch.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtSearch.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtSearch.Location = new System.Drawing.Point(152, 67);
            this.txtSearch.Name = "txtSearch";
            this.txtSearch.Size = new System.Drawing.Size(207, 20);
            this.txtSearch.TabIndex = 10;
            this.txtSearch.Visible = false;
            this.txtSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox1_KeyDown);
            // 
            // lblSearch
            // 
            this.lblSearch.AutoSize = true;
            this.lblSearch.Location = new System.Drawing.Point(18, 70);
            this.lblSearch.Name = "lblSearch";
            this.lblSearch.Size = new System.Drawing.Size(126, 13);
            this.lblSearch.TabIndex = 11;
            this.lblSearch.Text = "Search specific customer";
            this.lblSearch.Visible = false;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(552, 69);
            this.Controls.Add(this.lblSearch);
            this.Controls.Add(this.txtSearch);
            this.Controls.Add(this.lblEmailLoad);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.Text = "SEControlsBI";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblEmailLoad;
        private System.Windows.Forms.TextBox txtSearch;
        private System.Windows.Forms.Label lblSearch;
        private System.Windows.Forms.ToolStripMenuItem sendEmailToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
    }
}

