﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SEControlsBI.Properties;
using System.Xml;
using System.Xml.Linq;
using Microsoft.Win32.TaskScheduler;

namespace SEControlsBI
{
    public partial class frmSettings : Form
    {
        public frmSettings()
        {
            InitializeComponent();
        }

        XmlDocument doc = new XmlDocument();
        System.Reflection.Assembly a = System.Reflection.Assembly.GetExecutingAssembly();
        List<String> emailList = new List<String>();


        private void btnSave_Click(object sender, EventArgs e)
        {


            if (txtVLimit.Text != "")
            {
                Settings.Default["VarianceLimit"] = Convert.ToInt32(txtVLimit.Text);
            }

        
            else
            {
                MessageBox.Show("Excel file path is empty, system will continue to use old path");
            }

            if (chkAutoEmail.Checked == true)
            {
                Settings.Default["autoEmail"] = 1;

            }
            else
            {
                Settings.Default["autoEmail"] = 0;
            }



            string appLocation = AppDomain.CurrentDomain.BaseDirectory.ToString();


            using (TaskService ts = new TaskService())
            {

                if (numericUpDown1.Value != 0)
                {
                    try
                    {


                        ts.RootFolder.DeleteTask("SEControlsBIEmailAlert");


                    }

                    catch
                    {



                    }
                    finally

                    {

                        TaskDefinition td = ts.NewTask();
                        td.RegistrationInfo.Description = "Send Email Alert";

                        td.Triggers.Add(new DailyTrigger { DaysInterval = (short)numericUpDown1.Value } );

                        td.Actions.Add(new ExecAction(appLocation + @"SEControlsBI.exe", "dummyParameter", null));


                        ts.RootFolder.RegisterTaskDefinition("SEControlsBIEmailAlert", td);

                    }



                    Settings.Default["emailDays"] = Convert.ToInt32(numericUpDown1.Value);




                    MessageBox.Show("Settings Saved");
                    this.Close();


                }

                else if (chkAutoEmail.Checked == true)
                {
                    MessageBox.Show("Send email alert every day(s) value must be greater than 0");
                }



            }


    }


        private void frmSettings_Load(object sender, EventArgs e)
        {

            if (Convert.ToInt32(Settings.Default["autoEmail"]) == 1)
            {
                chkAutoEmail.Checked = true;
            }
            numericUpDown1.Value = Convert.ToInt32(Settings.Default["emailDays"]);
            txtVLimit.Text = Settings.Default["VarianceLimit"].ToString();
           
            
            doc.Load("AppData.xml");

            XmlElement root = doc.DocumentElement;
            XmlNodeList nodes = root.SelectNodes("email");
            foreach (XmlNode node in nodes)
            {

                lstEmails.Items.Add(node.InnerText);

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
        
           
            try
            {
                if (txtEmailAddress.Text != String.Empty)
                {
                    doc.Load("AppData.xml");
                    var emailAddress = new System.Net.Mail.MailAddress(txtEmailAddress.Text);

                    XmlElement root = doc.DocumentElement;
                    XmlNodeList elemList = root.GetElementsByTagName("email");
                    int CurrentEmail = elemList.Count + 1;

                    XmlNode settingNode = doc.SelectSingleNode("EmailAddress");

                    XmlElement newEmailElement = doc.CreateElement("email");
                    newEmailElement.SetAttribute("id", emailAddress.ToString());
                    newEmailElement.InnerText = emailAddress.ToString();
                    settingNode.AppendChild(newEmailElement);

                    doc.Save("AppData.xml");
                    lstEmails.Items.Add(txtEmailAddress.Text);
                    txtEmailAddress.Text = "";
                }


            }

            catch(FormatException ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
          
        }

       


        private void lstEmails_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (lstEmails.SelectedIndex != -1)
            {
                DialogResult dialogResult = MessageBox.Show("Would you like to remove the selected email from the list?", "Remove Email", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    string emailAddress = lstEmails.SelectedItem.ToString();
                    doc.Load("AppData.xml");


                    XmlNode emailNode = doc.SelectSingleNode("//email[@id='" + emailAddress + "']");



                    emailNode.ParentNode.RemoveChild(emailNode);
                    doc.Save("AppData.xml");
                    lstEmails.Items.Clear();
                    frmSettings_Load(null, null);

                }
                else if (dialogResult == DialogResult.No)
                {


                }





            }
        }

        private void chkAutoEmail_CheckedChanged(object sender, EventArgs e)
        {
            if (chkAutoEmail.Checked == true)
            {
                lblVLimit.Enabled = true;
                txtVLimit.Enabled = true;
                label1.Enabled = true;
                numericUpDown1.Enabled = true;
                label2.Enabled = true;
    



            }
            else
            {
                lblVLimit.Enabled = false;
                txtVLimit.Enabled = false;
                label1.Enabled = false;
                numericUpDown1.Enabled = false;
                label2.Enabled = false;
       

            }
        }

        private void txtEmailAddress_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                button1_Click(null, null);
            }
        }
    }
}
