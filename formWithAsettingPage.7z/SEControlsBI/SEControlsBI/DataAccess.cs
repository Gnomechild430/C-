﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml;
using System.Data.OleDb;
using System.Net.Mail;
using SEControlsBI.Properties;
using System.IO;



namespace SEControlsBI
{
    public class DataAccess
    {
        public static System.Data.DataTable dt = new System.Data.DataTable();
        string sqlConnectionString = @"Data Source=SECONS06;Initial Catalog=""SE Controls Live"";Persist Security Info=True;User ID=""adam.tate""; Password=triang!Estep;";
        PostCodeHelper postCodeHelper = new PostCodeHelper();
     



        public void LoadingCursor(string state)
        {
            if(state == "Load")
            {
                Cursor.Current = Cursors.WaitCursor;

            }

            else if (state == "Done")
            {
                Cursor.Current = Cursors.Default;
            }
            

        }



        public System.Data.DataTable GetValuesFromSQLServerCustomerSpecific(string CustomerID)
        {

          

            using (SqlConnection conn = new SqlConnection(sqlConnectionString))
            {
 
                string _customerID;

                if (CustomerID != "")
                {
                    _customerID = CustomerID;
                }

                else
                {
                    _customerID = "";
                }

                conn.Open();
                

string qry = @"
DECLARE @LastmonthStartDate varchar(50)
DECLARE @LastmonthEndDate varchar(50)

DECLARE	@2MonthsStartDate varchar(50)
DECLARE @2MonthsEndDate varchar(50)

DECLARE @CurrentMonthStartDate varchar(50)
DECLARE @CurrentMonthEndDate varchar(50)


SET @CurrentMonthStartDate =  DATEADD(MONTH, DATEDIFF(MONTH, 0,GETDATE()) , 0)
SET @CurrentMonthEndDate = DATEADD(SECOND, -1, DATEADD(MONTH, 1,  DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) , 0) ) )

SET @LastMonthStartDate = DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE())-1, 0)
SET @LastmonthEndDate = DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE())-1, -1)

SET @2MonthsStartDate = DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE())-2, 0)
SET @2MonthsEndDate = DATEADD(MONTH, DATEDIFF(MONTH, -1, GETDATE())-2, -1)
 

SELECT DISTINCT a.[Sell-to Customer No_] as Customer,c.[Name],
SUM(CASE WHEN a.[Order Date] >= @CurrentMonthStartDate
AND a.[Order Date] < @CurrentMonthEndDate THEN b.[Line Amount] ELSE 0 END) 'Orders This Month',

SUM(CASE WHEN a.[Order Date] >= @LastmonthStartDate
AND a.[Order Date] < @LastmonthEndDate THEN b.[Line Amount] ELSE 0 END) 'Orders Last Month',

SUM(CASE WHEN a.[Order Date] >= @2MonthsStartDate
AND a.[Order Date] < @2MonthsEndDate THEN b.[Line Amount] ELSE 0 END) 'Orders 2 Months Ago',c.[Post Code]
FROM[dbo].[S E Controls Live$Sales Header] a
INNER JOIN[dbo].[S E Controls Live$Sales Line] b ON a.No_ = b.[Document No_]
INNER JOIN[S E Controls Live$Customer] c on c.No_ = a.[Sell-to Customer No_]
WHERE a.[Document Type] = 1 AND(a.[Shortcut Dimension 1 Code] = 'SUPPLY' OR a.[Gen_ Bus_ Posting Group] = 'SUPPLY') AND (a.[Sell-to Customer No_]
LIKE '" + _customerID + "%' OR  c.[Name] LIKE '%" + _customerID + "%')  GROUP BY a.[Sell-to Customer No_],c.[Name],c.[Post Code] ORDER BY 'Orders 2 Months Ago' DESC";

                SqlCommand cmd = new SqlCommand(qry, conn);
                SqlDataAdapter sqlDataAdap = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();
                sqlDataAdap.Fill(dt);

                return dt;


            }

        }


/// <summary>
/// Gets the supply customers order values from the SQL server for CurrentMonth,LastMonth,2MonthsAgo. SUM(Line Ammount)
/// </summary>
/// <returns>
/// Data Table including sales data.
/// </returns>

        public System.Data.DataTable GetSalesValueFromSQLServer()

        {

     


            SqlConnection conn = new SqlConnection(sqlConnectionString);
            conn.Open();

        
                string qry = @"

            SELECT DISTINCT a.[Sell-to Customer No_] as Customer,c.[Name],
            SUM(CASE WHEN a.[Order Date] >= GetDate() -30
            AND a.[Order Date] < GetDate() THEN b.[Line Amount] ELSE 0 END) 'Orders Last 30 Days',

            SUM(CASE WHEN a.[Order Date] >= GetDate() -60
            AND a.[Order Date] < GetDate() - 30 THEN b.[Line Amount] ELSE 0 END) 'Between 30 days ago and 60 days ago',

            SUM(CASE WHEN a.[Order Date] >= GetDate() - 90
            AND a.[Order Date] < GetDate() -60 THEN b.[Line Amount] ELSE 0 END) 'Between 60 days ago and 90 days ago'
            ,c.[Post Code]
            FROM[dbo].[S E Controls Live$Sales Header] a
            INNER JOIN[dbo].[S E Controls Live$Sales Line] b ON a.No_ = b.[Document No_]
            INNER JOIN[S E Controls Live$Customer] c on c.No_ = a.[Sell-to Customer No_]
            WHERE a.[Document Type] = 1 AND(a.[Shortcut Dimension 1 Code] = 'SUPPLY' OR a.[Gen_ Bus_ Posting Group] = 'SUPPLY')
          GROUP BY a.[Sell-to Customer No_],c.[Name],c.[Post Code] ORDER BY 'Between 60 days ago and 90 days ago' DESC";
            

         
            

            try
            {
                SqlCommand cmd = new SqlCommand(qry, conn);
                SqlDataAdapter sqlDataAdap = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();
                sqlDataAdap.Fill(dt);

                return dt;
            }
        catch   (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
                return null;
            }
                


            }


        
        public DataTable MapCustomerPostCodeToRegion(DataTable customerPostCode)
        {
            DataTable pstTBL = postCodeHelper.GetPostCodesFromCSV();

            string TAM = "";
            string lookup = "";
      
              foreach (DataRow row in customerPostCode.Rows)
            {
                string sector = row["ShortPC"].ToString();
                
                foreach (DataRow csvRow in pstTBL.Rows)
                {
                    lookup = csvRow[0].ToString();
                    if (sector ==lookup)
                    {
                        
                        TAM = csvRow[1].ToString();
                        row["TAM"] = TAM;

                    }

                }


            }
            return dt;

        
        }



/// <summary>
/// Run analysis on each row in the data table and calculates the percentage parameter from settings. E.g if the setting is 20% then it will 
/// multiply the order values from 2 months ago * 0.8 and *1.2. If the sales value from last month is higher than Value*1.2 or lower than 
/// Value*0.8 then it will be added to the string builder which constructs the email.
/// </summary>
/// <param name="dt"></param>
        public void RunDataAnalsysis(DataTable dt)
        {
            string currentMonth = DateTime.Now.ToString("MMMM");
            string currentYear = DateTime.Now.Year.ToString();
            XMLData.emailContent.Append(@"<table border=""1""> <tr><th>Customer Name</th> <th> Data Analysis </th><th>Order Value Last 30 days <br> (" + currentMonth + " - " + currentYear + ")</th><th>Order Value Between 30 and 60 days ago </th><th>Order Value Between 60 and 90 days ago </th></tr>");
            XMLData.emailContentNorth.Append(@"<table border=""1""> <tr><th>Customer Name</th> <th> Data Analysis </th><th>Order Value 30 days <br> (" + currentMonth + " - " + currentYear + ")</th><th>Order Value Between 30 and 60 days ago</th><th>Order Value Between 60 and 90 days ago </th></tr>");
            XMLData.emailContentSouth.Append(@"<table border=""1""> <tr><th>Customer Name</th> <th> Data Analysis </th><th>Order Value 30 days <br> (" + currentMonth + " - " + currentYear + ")</th><th>Order Value Between 30 and 60 days ago</th><thOrder Value Between 60 and 90 days ago </th></tr>");


            string TAM;
            frmMain frm1 = new frmMain();
            StringBuilder sb = new StringBuilder();
            double oneMonth, twoMonth, threeMonth;
            double percentage = (Convert.ToInt32(Settings.Default["VarianceLimit"]));
            double dPercentage = percentage / 100;
            double one = 1;
            double difference;
            double decrease;
     
 


            foreach (DataRow row in dt.Rows)
            {
                TAM = Convert.ToString(row["TAM"]);

                oneMonth = Convert.ToDouble(row["Between 60 days ago and 90 days ago"]);
                twoMonth = Convert.ToDouble(row["Between 30 days ago and 60 days ago"]);
                threeMonth = Convert.ToDouble(row["Between 60 days ago and 90 days ago"]);


                // if the sales from 2 months ago is smaller than the threemonths sales - 20% then the sales have decreased by more than 20% i
                if (twoMonth < threeMonth * (one - dPercentage))
                {
                    decrease = threeMonth - twoMonth;
                    difference = Math.Round((decrease / threeMonth) * 100, 3);
// Switch statement that constructs a string depending on the area.
                    switch (TAM)
                    {
                        case "E":
                            XMLData.emailContent.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have decreased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago , with a " + difference.ToString() + " % decrease</td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;
                        case "N":
                            XMLData.emailContentNorth.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have decreased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago , with a " + difference.ToString() + " % decrease</td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;
                        case "S":
                            XMLData.emailContentSouth.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have decreased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago , with a " + difference.ToString() + " % decrease</td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;
                        case "M":
                            XMLData.emailContentMidlands.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have decreased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago , with a " + difference.ToString() + " % decrease</td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;

                    }
                }
                // if the sales from 2 months ago is higher than threemonths + 20% then there is more than a 20% increase in sales within the one month.
                else if (twoMonth > threeMonth * (one + dPercentage))
                {
                    decrease = twoMonth - threeMonth;
                    difference = Math.Round((decrease / twoMonth) * 100, 3);


                    switch (TAM) {
                        case "E":
                    XMLData.emailContent.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have increased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago with a " + difference.ToString() + " % increase </td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;
                        case "N":
                            XMLData.emailContentNorth.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have increased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago with a " + difference.ToString() + " % increase </td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;
                        case "S":
                            XMLData.emailContentSouth.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have increased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago with a " + difference.ToString() + " % increase </td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;
                        case "M":
                            XMLData.emailContentMidlands.Append(@"<tr> <td> " + row["Name"] + " </td><td> Orders have increased by " + Settings.Default["VarianceLimit"].ToString() + " % or more when comparing orders from 3 months ago to orders 2 months ago with a " + difference.ToString() + " % increase </td><td>" + oneMonth.ToString("C0") + "</td><td>" + twoMonth.ToString("C0") + "</td><td>" + threeMonth.ToString("C0") + "</td></tr>");
                            break;  


                    } }
               

            }

        }
        







    }
}

        

            




   

