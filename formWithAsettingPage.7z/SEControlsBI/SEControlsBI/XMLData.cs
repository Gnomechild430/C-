﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace SEControlsBI
{
    public class XMLData
    {
        public static StringBuilder emailContent = new StringBuilder(); // (EXPORT)
        public static StringBuilder emailContentNorth = new StringBuilder();
        public static StringBuilder emailContentSouth = new StringBuilder();
        public static StringBuilder emailContentMidlands = new StringBuilder();



        public XmlNodeList GetEmails()
        {

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load("AppData.xml");

            XmlElement root = xmlDoc.DocumentElement;
            XmlNodeList nodes = root.SelectNodes("email");

            return nodes;
            
        }
        
}
}
