﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Net.Mail;

namespace SEControlsBI
{
    public class Email
    {

        XMLData xmlData = new XMLData();

        public void SendEmail(string EmailBody,string subject,int queryType,int area)

        {
            if (EmailBody != "")
            {


                StringBuilder emailList = new StringBuilder();
                XmlNodeList listOfEmails = xmlData.GetEmails();

                foreach (XmlNode node in listOfEmails)
                {

                    emailList.Append(node.InnerText + ";");
                }

                string emailTo = emailList.ToString();
                emailTo = emailTo.TrimEnd(';');
                MailMessage mail = new MailMessage("NOREPLY.BI-Reports@secontrols.com", "adam.tate@secontrols.com");
              

                foreach (var address in emailTo.Split(new[] { ";" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    mail.To.Add(address);
                }


                // 1 = North
                // 2 = Midlands
                // 3 = South
                // 4 = Export

                //switch (area)
                //{
                //    case 1:
                //        mail.To.Add("Simon.Cooney@secontrols.com");
                //        break;
                //    case 2:
                //        mail.To.Add("Chris.Shilton@secontrols.com");
                //        break;
                //    case 3:
                //        mail.To.Add("Tom.Courtney@secontrols.com");
                //        break;

                //}

                //TEST BELOW
                switch (area)
                {
                    case 1:
                        mail.To.Add("adam.tate@secontrols.com");
                        break;
                    case 2:
                        mail.To.Add("adam.tate@secontrols.com");
                        break;
                    case 3:
                        mail.To.Add("adam.tate@secontrols.com");
                        break;
                    case 4:
                        mail.To.Add("adam.tate@secontrols.com");
                        break;

                }




                SmtpClient client = new SmtpClient();

                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                //client.Host = "eu-smtp-outbound-1.mimecast.com";
                client.Host = "192.196.113.151";

                mail.Subject = "Bi Reports";
                mail.IsBodyHtml = true;

                // 1 = North
                // 2 = Midlands
                // 3 = South
                // 4 = Export


                if (queryType == 1)
                {


                    switch (area) {

                        case 1:
                    mail.Body = @"<h1>Supply Customers (North) Auto Alert</h1> <br> " + XMLData.emailContentNorth.ToString();
                            break;
                        case 2:
                    mail.Body = "<h1>Supply Customers (Midlands) Auto Alert</h1> <br> " + XMLData.emailContentMidlands.ToString();
                     break;
                        case 3:
                            mail.Body = "<h1>Supply Customers (South) Auto Alert</h1> <br> " + XMLData.emailContentSouth.ToString();
                            break;
                        case 4:
                            mail.Body = "<h1>Supply Customers (Export) Auto Alert</h1> <br> " + XMLData.emailContent.ToString();
                            break;

                    }
                }
                try
                {
                    client.Send(mail);
                }
                catch (Exception)
                {
                    
                }

            }

        }
    }
}