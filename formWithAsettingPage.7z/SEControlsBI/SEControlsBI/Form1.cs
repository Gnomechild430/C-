﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Xml;
using System.Data.OleDb;
using System.Net.Mail;
using SEControlsBI.Properties;


namespace SEControlsBI
{
    public partial class frmMain : Form
    {
        public frmMain()
        {

            InitializeComponent();
        }

        XMLData xmlData = new XMLData();
        Email email = new Email();
        DataAccess dataAccess = new DataAccess();
        List<Mapping> lstMap = new List<Mapping>();
        PostCodeHelper postCoderHelper = new PostCodeHelper();

// Manually runs the selected query.
        private void button3_Click(object sender, EventArgs e)
        {
            var dgv = new DataGridView();
           

            dataAccess.LoadingCursor("Load");
            DrawGrid(24);
            StartCalc(false);
            txtSearch.Visible = true;
            lblSearch.Visible = true;
            dataGridView1.Visible = true;
            int height = dataGridView1.Rows.Count;
            dataGridView1.Columns[2].DefaultCellStyle.Format = "c";
            dataGridView1.Columns[3].DefaultCellStyle.Format = "c";
            dataGridView1.Columns[4].DefaultCellStyle.Format = "c";
   
            dataAccess.LoadingCursor("Done");
            dgv.RowTemplate.Height = height;
        }


// Main application function.
        private void StartCalc(bool ScheduleTask)
        {
            string TAM = "";
            
            int queryType;
            if (comboBox1.Text == "Customer Order Analysis ")
            {
                
                ClearDGV();
                UpdateDataGridView(dataAccess.GetSalesValueFromSQLServer());
               
                DataTable dt = dataAccess.GetSalesValueFromSQLServer();

                dt.Columns.Add("ShortPC", typeof(string));
                dt.Columns.Add("TAM", typeof(string));

                foreach (DataRow row in dt.Rows)
                {
                   
                    TAM = postCoderHelper.GetSector(row["Post Code"].ToString());
                    row["ShortPC"] = TAM;
               



                }
                dataGridView1.DataSource = dt;
                dataGridView1.Update();
                dataGridView1.Refresh();
                dataAccess.MapCustomerPostCodeToRegion(dt);
                dataAccess.RunDataAnalsysis(dt);
                dataGridView1.DataSource = dt;
                dataGridView1.Update();
                dataGridView1.Refresh();







                bool sendEmail = Convert.ToBoolean(Settings.Default["autoEmail"]);

                if (sendEmail == true)
                {
                    queryType = 1;
                    email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType,1);
                    email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 2);
                    email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 3);
                    email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 4);

                }
            }

// If the application has been started with a scheduled task then run the application as if the user was clicking "Run". 
// REQUIREMENT - Need to add into settings which querys are ran (When more are added).

            if (ScheduleTask == true)
            {
                queryType = 1;

                this.Hide();

                ClearDGV();
                UpdateDataGridView(dataAccess.GetSalesValueFromSQLServer());
                dataAccess.RunDataAnalsysis(dataAccess.GetSalesValueFromSQLServer());
               
                
                bool sendEmail = Convert.ToBoolean(Settings.Default["autoEmail"]);



                email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 1);
                email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 2);
                email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 3);
                email.SendEmail(XMLData.emailContent.ToString(), "Bi Reports", queryType, 4);



                System.Environment.Exit(1);
            }
        }


//Updates the data grid view with the data table passed in.
        private void UpdateDataGridView(DataTable dt)
        {           
            dataGridView1.DataSource = dt;
        }

// Clears the data grid view visually on the form and clears out the application data tables.
        public void ClearDGV()

        {
            dataGridView1.DataSource = "";
            dataGridView1.Update();
            dataGridView1.Refresh();
            DataAccess.dt.Clear();
            DataAccess.dt.Columns.Clear();
        }

 // Refreshes the data in the grid view.
        public void RefreshGridView() {
            dataGridView1.Update();
          
        }

      

// Opens the settings form.
        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSettings formSettings = new frmSettings();
            formSettings.Show();
        }

 // Creates a string array and populates it with the command line arguments - This is used to determine whether it has been started by a sheduled task. 
        private void Form1_Load(object sender, EventArgs e)
        {
            backgroundWorker1.RunWorkerAsync();
            bool sched = false;

            string[] args = Environment.GetCommandLineArgs();



            
// If there are arguments passed in then it will be run as a scheduled task. (Same settings are used).

            if (args.Length >= 2)
            {
                sched = true;
                StartCalc(sched);
                this.Hide();
            }
                  
        }

// Saves the settings when the form is closed.
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Properties.Settings.Default.Save();
        }


// Whilst in the "Search by specific customer text box", if the user presses the enter key then it will search for only those customers on the selected queries.
        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyData == Keys.Enter)
            {
                if (comboBox1.Text == "Customer Order Analysis ")

                {
                    ClearDGV();
                    UpdateDataGridView(dataAccess.GetValuesFromSQLServerCustomerSpecific(txtSearch.Text));

                    dataGridView1.Columns[2].DefaultCellStyle.Format = "c";
                    dataGridView1.Columns[3].DefaultCellStyle.Format = "c";
                    dataGridView1.Columns[4].DefaultCellStyle.Format = "c";
               
                    int height = dataGridView1.Rows.Count;
                    DrawGrid(height);

                }
            }
        }
        
// Manually send the email of the selected query (Manual Only)
        private void sendEmailToolStripMenuItem_Click(object sender, EventArgs e)
        {
            int queryType = 0;

            if (XMLData.emailContent.ToString() != String.Empty)
            {

                if (comboBox1.Text == "Customer Order Analysis ")
                {

                    queryType = 1;

                    email.SendEmail(XMLData.emailContent.ToString(), "Email Auto Alert (North)", queryType, 1);
                    email.SendEmail(XMLData.emailContent.ToString(), "Email Auto Alert (Midlands)", queryType, 2);
                    email.SendEmail(XMLData.emailContent.ToString(), "Email Auto Alert (South)", queryType, 3);
                    email.SendEmail(XMLData.emailContent.ToString(), "Email Auto Alert (Export)", queryType, 4);

                }
            }
            else
            {
                MessageBox.Show("There has been no data formed to send an email, please run a query from the drop down menu first.");
            }

        }

// Shows the search box for specific customer. This will be tailored to the selected query when more are added.
        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            txtSearch.Visible = false;
            lblSearch.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
          //  postCoderHelper.GetSector("G32 8HJ");
            postCoderHelper.GetPostCodesFromCSV();
        }
    }

}
